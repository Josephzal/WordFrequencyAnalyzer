package application;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

import application.Scene2Controller;

/**
 * The testAdd class
 * @author lomba
 *
 */
class testAdd {


	/**
	 * The countTest method tests that the occurrences retrieved by the 
	 * scanFile method are accurate.
	 */
	@Test
	void test() throws FileNotFoundException {
		//Class to test
	    Scene2Controller test = new Scene2Controller();
	    //Variable to test
        int x = test.countTest("MacbethPlay.txt");
		//Check that output gives expected result
		assertEquals(7733, x);
	}

}
