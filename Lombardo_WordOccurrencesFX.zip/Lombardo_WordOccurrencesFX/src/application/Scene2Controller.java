// Author Name: Joseph Lombardo
package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Scene2Controller {
	
	//Inject FXML for scene builder integration
	@FXML
	Label wordsLabel;
	@FXML
	Button goBackButton;
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	
	// Method to scan files and output sorted word frequency
	public void displayOccurrences(File wordsFile) throws FileNotFoundException {

		Map<String, Integer> freq = new HashMap<>();

				Scanner scanner = new Scanner(wordsFile);
				while(scanner.hasNext()) {
					String word = scanner.next();
					String lettersOnly = word.replaceAll("[\\W]", "").toLowerCase();
					if(lettersOnly.equals("")) {
						continue;
					}
					if(!freq.containsKey(lettersOnly)) {
						freq.put(lettersOnly, 1);
					}
					else {
						int x = freq.get(lettersOnly)+1;
						freq.put(lettersOnly, x);
					}
				}
				scanner.close();


		//Use stream to sort words in descending order by comparing each word 
		//by their values (frequency) and output the results of the sorted list
		StringBuilder result = new StringBuilder();
		freq.entrySet().stream()
        .sorted((word1, word2) -> -word1.getValue().compareTo(word2.getValue()))
        .forEach(word -> result.append("The word ( " + word.getKey() + " ) occurrs " + word.getValue() + " times.\n"));
		wordsLabel.setText(String.valueOf(result));
		
	}

	// Method for the back button to go back to initial scene
	public void goBack (ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene1.fxml"));
		root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}
