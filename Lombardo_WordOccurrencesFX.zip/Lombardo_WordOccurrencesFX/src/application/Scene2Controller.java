// Author Name: Joseph Lombardo
package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controller class for Scene 2
 * @author lomba
 *
 */
public class Scene2Controller {
	
	//Inject FXML for scene builder integration
	@FXML
	Label wordsLabel;
	@FXML
	Button goBackButton;
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	Map<String, Integer> freq = new HashMap<>();
	
	// Method to output sorted word frequency
	/**
	 * The displayOccurrences method calls the scanFile method on the file passed.
	 * The data provided by the scanFile method is passed into a StringBuilder to display these
	 * occurrences, and a stream is used to sort words in descending order of frequency.
	 * @param wordsFile File entered by user to be scanned.
	 * @throws FileNotFoundException Error message if the file is not found.
	 */
	public void displayOccurrences(File wordsFile) throws FileNotFoundException {
        scanFile(wordsFile);

		//Use stream to sort words in descending order by comparing each word 
		//by their values (frequency) and output the results of the sorted list
		StringBuilder result = new StringBuilder();
		freq.entrySet().stream()
        .sorted((word1, word2) -> -word1.getValue().compareTo(word2.getValue()))
        .forEach(word -> result.append("The word ( " + word.getKey() + " ) occurrs " + word.getValue() + " times.\n"));
		wordsLabel.setText(String.valueOf(result));
		
		
	}
	
	// Method to scan through file and add occurrences to a HashMap
	/**
	 * This method takes the file and scans for unique words. The frequency
	 * of unique words is passed into a HashMap where the words are the key and 
	 * the frequency is the value. If a file is not found, an error message states so.
	 * @param wordsFile File entered by user to be scanned
	 * @throws FileNotFoundException Error message if the file is not found.
	 */
	public void scanFile(File wordsFile) throws FileNotFoundException {
		Scanner scanner = new Scanner(wordsFile);
		while(scanner.hasNext()) {
			String word = scanner.next();
			String lettersOnly = word.replaceAll("[\\W]", "").toLowerCase();
			if(lettersOnly.equals("")) {
				continue;
			}
			if(!freq.containsKey(lettersOnly)) {
				freq.put(lettersOnly, 1);
			}
			else {
				int x = freq.get(lettersOnly)+1;
				freq.put(lettersOnly, x);
			}
		}
		scanner.close();
	}

	// Method for the back button to go back to initial scene
	/**
	 * The goBack method is used to return to the main menu by clicking
	 * the back button.
	 * @param event The button used to go back to main menu.
	 * @throws IOException The exception thrown if error occurs.
	 */
	public void goBack (ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene1.fxml"));
		root = loader.load();
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	/**
	 * The countTest method tests that the occurrences retrieved by the 
	 * scanFile method are accurate.
	 * @param f String to be tested for an accurate account of occurrences.
	 * @return The result of occurrences found for the string.
	 * @throws FileNotFoundException Error message if the file is not found.
	 */
	public int countTest(String f) throws FileNotFoundException {
		File file = new File(f);
		scanFile(file);
		return freq.get("the");
	}
	
	/**
	 * The nameTest method tests to ensure that the scanFile method is adding
	 * the appropriate words found in the file to the HashMap.
	 * @param f The file to be tested.
	 * @param s The word to be searched for.
	 * @return The result of whether or not the specified word is found in the file.
	 * @throws FileNotFoundException Error message if the file is not found.
	 */
	public boolean nameTest(String f, String s) throws FileNotFoundException {
		File file = new File(f);
		scanFile(file);
		if(freq.containsKey(s)) {
			return true;
		}
		else {
			return false;
		}
	}
}
