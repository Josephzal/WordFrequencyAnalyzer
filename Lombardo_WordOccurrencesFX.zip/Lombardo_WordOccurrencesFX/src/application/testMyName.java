package application;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

/**
 * The testmyName class.
 * @author lomba
 */
class testMyName {

	/**
	 * The nameTest method tests to ensure that the scanFile method is adding
	 * the appropriate words found in the file to the HashMap.
	 */
	@Test
	void test() throws FileNotFoundException {
		//Class to test
	    Scene2Controller test = new Scene2Controller();
	    //Variable to test
        boolean x = test.nameTest("MacbethPlay.txt", "the");
		//Check that output gives expected result
		assertEquals(true, x);
	}

}
