// Author Name: Joseph Lombardo
// Date: 6/25/2021
// Program Name: Lombardo_WordOccurrencesFX
// Purpose: Scan files to present an output of the word frequency, sorting from highest to lowest. 
//		    Apply GUI to the program to allow for an intuitive user experience.
package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		
		// Try/Catch block to set and show initial scene
		try {
			Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
			Scene scene = new Scene(root,600,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			// Set app icon
			Image icon = new Image("bookIcon.png");
			primaryStage.resizableProperty().set(false);
			primaryStage.setTitle("Word Occurrences");
			primaryStage.getIcons().add(icon);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// Launch the stage on app startup
		launch(args);
	}
}
