// Author Name: Joseph Lombardo
package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controller class for Scene 1
 * @author lomba
 *
 */
public class Scene1Controller {
	
	//Inject FXML for scene builder integration
	@FXML
	TextField fileTextField;
	@FXML
	Label msg;
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	
	// Method for button, checks if the text input is a file
	// If it is, continue onto next scene, else present error message
	/**
	 * The analyze method will first check if input exists as a file on the system.
	 * If input is not a file, will output error message stating so.
	 * If it is a file, it will pass this information over to Scene 2.
	 * @param event The button used to scan the file.
	 * @throws IOException The error message if file is not found.
	 */
	public void analyze(ActionEvent event) throws IOException {

		File fileName;
		
			try {
				fileName = new File(fileTextField.getText());
				if(!fileName.isFile()) {
					msg.setText("File not found");
					return;
				}
			}
			catch(Exception e) {
				msg.setText("File not found");

				return;
			}
		// Load into next scene
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene2.fxml"));
		root = loader.load();
		
		//Call method to display word occurrences from scene2
		Scene2Controller scene2Controller = loader.getController();
		scene2Controller.displayOccurrences(fileName);
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

}
